import React, { useState, useEffect } from "react";
// import "./Marquee.css"; // Import your CSS file
import Marquee from "react-fast-marquee";
const MarqueeImage = ({ images, scrollSpeed }) => {

  return (
    // <div className="marquee-container">
    //   <Marquee direction="up" speed={0.05}>
    //      {images.map((image, index) => (
    //       <img key={index} src={image} alt={`Image ${index}`} />
    //     ))}
    //   </Marquee>
    // </div>
    <>

    </>
  );
};

export default MarqueeImage;
