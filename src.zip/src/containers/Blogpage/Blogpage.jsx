import React from 'react'

export default function Blogpage() {
  return (
    // <!-- select option -->

    // <section className="py-2 vjed-blog-section">
    //     <div className="container-fluid">
    //         <div className="row">

    //           <div className="co-md-12">

    //           </div>

    //           <div className="col-md-12">

    //           </div>
    //           <div className="col-lg-8 col-md-6">
    //             <div className="p-1  bg-white shadow">
    //               <select className="selectpicker" data-live-search="true" data-container="body">
    //                   <option data-tokens="ketchup mustard">CBSC STUDY MATERIAL</option>
    //                   <option data-tokens="mustard">Burger, Shake and a Smile</option>
    //                   <option data-tokens="frosting">Sugar, Spice and all things nice</option>
    //               </select>
    //               <select className="selectpicker" data-live-search="true" data-container="body">
    //                   <option data-tokens="ketchup mustard">RD Sharma Solutions</option>
    //                   <option data-tokens="mustard">Burger, Shake and a Smile</option>
    //                   <option data-tokens="frosting">Sugar, Spice and all things nice</option>
    //               </select>
    //           </div>
    //             <div className="add-img my-2 shadow">

    //               <img src="images/vjads2.png" alt="vjads"  className="img-fluid"/>

    //             </div>
    //             <div className="vjed-blog-page shadow">
    //               <!-- bolg-1 -->
    //               <div className="blog-section">
    //                 <!-- block heading -->
    //                 <div className="vjed-blog-heading mb-3">
    //                   <h2 className="vjed-blog-title">
    //                     How can 5G benefit the Mobile App Development Industry?
    //                   </h2>
    //                 </div>
    //                 <!-- block img -->
    //                 <div className="vjed-blog-img mb-3">
    //                   <a href="blog-section.html">
    //                   <img src="images/blog-1.png" className="img-fluid"/>
    //                 </a>
    //                 </div>
    //                  <!-- block Description -->
    //                 <div className="vjed-blog-des mb-3">
    //                   <p>Today, we rely on the internet to complete even our daily tasks, even the basic ones. From searching for a grocery store nearby to ordering those groceries at home. Currently, everything is at our disposal because many things are available online. Here, we are using the internet to complete our daily work. Starting from the first generation internet or 1G, today, we have a 5G network. </p>
    //                 </div>

    //                  <!-- block Read more -->
    //                  <div className="blog-read-more mb-3">
    //                    <div className="d-flex justify-content-between align-items-center">
    //                        <div className="blog-post-read">
    //                           <h6>
    //                             <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                             14-jun-2023
    //                           </h6>
    //                        </div>
    //                        <div className="blog-post-read">
    //                         <h6>
    //                           <i className="fa fa-cloud-upload me-1" aria-hidden="true"></i>
    //                            Posted By <a href="#">Admin</a>
    //                         </h6>
    //                        </div>
    //                        <div className="view-all-py">
    //                         <a  href="blog-section.html">Read More</a>
    //                        </div>
    //                    </div>
    //                  </div>

    //               </div>
    //               <!-- bolg-2 -->
    //               <div className="blog-section">
    //                 <!-- block heading -->
    //                 <div className="vjed-blog-heading mb-3">
    //                   <h2 className="vjed-blog-title">
    //                     All About AWS MediaConvert Vs AWS Elemental MediaLive
    //                   </h2>
    //                 </div>
    //                 <!-- block img -->
    //                 <div className="vjed-blog-img mb-3">
    //                   <img src="images/blog-2.png" className="img-fluid"/>
    //                 </div>
    //                  <!-- block Description -->
    //                 <div className="vjed-blog-des mb-3">
    //                   <p>At present, video streaming is leading the world, and every business is looking forward to accepting it. However, not all companies can use this to expand their activities. The lack of encoded videos creates many problems; therefore, they require AWS Elemental MediaLive. Moreover, the absence of video file processing and on-demand videos also creates many hurdles. </p>
    //                 </div>

    //                  <!-- block Read more -->
    //                  <div className="blog-read-more mb-3">
    //                    <div className="d-flex justify-content-between align-items-center">
    //                        <div className="blog-post-read">
    //                           <h6>
    //                             <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                             14-jun-2023
    //                           </h6>
    //                        </div>
    //                        <div className="blog-post-read">
    //                         <h6>
    //                           <i className="fa fa-cloud-upload me-1" aria-hidden="true"></i>
    //                            Posted By <a href="#">Admin</a>
    //                         </h6>
    //                        </div>
    //                        <div className="view-all-py">
    //                         <a  href="#">Read More</a>
    //                        </div>
    //                    </div>
    //                  </div>

    //               </div>
    //               <!-- bolg-3 -->
    //               <div className="blog-section">
    //                 <!-- block heading -->
    //                 <div className="vjed-blog-heading mb-3">
    //                   <h2 className="vjed-blog-title">
    //                     All About AWS MediaConvert Vs AWS Elemental MediaLive
    //                   </h2>
    //                 </div>
    //                 <!-- block img -->
    //                 <div className="vjed-blog-img mb-3">
    //                   <img src="images/blog-3.png" className="img-fluid"/>
    //                 </div>
    //                  <!-- block Description -->
    //                 <div className="vjed-blog-des mb-3">
    //                   <p>At present, video streaming is leading the world, and every business is looking forward to accepting it. However, not all companies can use this to expand their activities. The lack of encoded videos creates many problems; therefore, they require AWS Elemental MediaLive. Moreover, the absence of video file processing and on-demand videos also creates many hurdles.</p>
    //                 </div>

    //                  <!-- block Read more -->
    //                  <div className="blog-read-more mb-3">
    //                    <div className="d-flex justify-content-between align-items-center">
    //                        <div className="blog-post-read">
    //                           <h6>
    //                             <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                             14-jun-2023
    //                           </h6>
    //                        </div>
    //                        <div className="blog-post-read">
    //                         <h6>
    //                           <i className="fa fa-cloud-upload me-1" aria-hidden="true"></i>
    //                            Posted By <a href="#">Admin</a>
    //                         </h6>
    //                        </div>
    //                        <div className="view-all-py">
    //                         <a  href="#">Read More</a>
    //                        </div>
    //                    </div>
    //                  </div>

    //               </div>
    //               <!-- bolg-4 -->
    //               <div className="blog-section">
    //                 <!-- block heading -->
    //                 <div className="vjed-blog-heading mb-3">
    //                   <h2 className="vjed-blog-title">
    //                     All About AWS MediaConvert Vs AWS Elemental MediaLive
    //                   </h2>
    //                 </div>
    //                 <!-- block img -->
    //                 <div className="vjed-blog-img mb-3">
    //                   <img src="images/blog-4.png" className="img-fluid"/>
    //                 </div>
    //                  <!-- block Description -->
    //                 <div className="vjed-blog-des mb-3">
    //                   <p>At present, video streaming is leading the world, and every business is looking forward to accepting it. However, not all companies can use this to expand their activities. The lack of encoded videos creates many problems; therefore, they require AWS Elemental MediaLive. Moreover, the absence of video file processing and on-demand videos also creates many hurdles.</p>
    //                 </div>

    //                  <!-- block Read more -->
    //                  <div className="blog-read-more mb-3">
    //                    <div className="d-flex justify-content-between align-items-center">
    //                        <div className="blog-post-read">
    //                           <h6>
    //                             <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                             14-jun-2023
    //                           </h6>
    //                        </div>
    //                        <div className="blog-post-read">
    //                         <h6>
    //                           <i className="fa fa-cloud-upload me-1" aria-hidden="true"></i>
    //                            Posted By <a href="#">Admin</a>
    //                         </h6>
    //                        </div>
    //                        <div className="view-all-py">
    //                         <a  href="#">Read More</a>
    //                        </div>
    //                    </div>
    //                  </div>

    //               </div>
    //               <!-- bolg-5 -->
    //               <div className="blog-section">
    //                 <!-- block heading -->
    //                 <div className="vjed-blog-heading mb-3">
    //                   <h2 className="vjed-blog-title">
    //                     All About AWS MediaConvert Vs AWS Elemental MediaLive
    //                   </h2>
    //                 </div>
    //                 <!-- block img -->
    //                 <div className="vjed-blog-img mb-3">
    //                   <img src="images/blog-5.png" className="img-fluid"/>
    //                 </div>
    //                  <!-- block Description -->
    //                 <div className="vjed-blog-des mb-3">
    //                   <p>At present, video streaming is leading the world, and every business is looking forward to accepting it. However, not all companies can use this to expand their activities. The lack of encoded videos creates many problems; therefore, they require AWS Elemental MediaLive. Moreover, the absence of video file processing and on-demand videos also creates many hurdles.</p>
    //                 </div>

    //                  <!-- block Read more -->
    //                  <div className="blog-read-more mb-3">
    //                    <div className="d-flex justify-content-between align-items-center">
    //                        <div className="blog-post-read">
    //                           <h6>
    //                             <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                             14-jun-2023
    //                           </h6>
    //                        </div>
    //                        <div className="blog-post-read">
    //                         <h6>
    //                           <i className="fa fa-cloud-upload me-1" aria-hidden="true"></i>
    //                            Posted By <a href="#">Admin</a>
    //                         </h6>
    //                        </div>
    //                        <div className="view-all-py">
    //                         <a  href="#">Read More</a>
    //                        </div>
    //                    </div>
    //                  </div>

    //               </div>
    //             </div>
    //             <div className="blog-pagination p-2 shadow rounded-3 bg-white my-2">
    //                 <div className="justify-content-between d-flex mt-1">
    //                   <div className="view-all-py mb-0">
    //                     <a  href="#">Previous</a>
    //                    </div>
    //                    <div className="text-center ">
    //                     <p>Page 1/20</p>
    //                    </div>

    //                    <div className="view-all-py mb-0">
    //                     <a  href="#">Next</a>
    //                    </div>
    //                 </div>
    //             </div>
    //           </div>


    //           <div className="col-lg-4 col-md-6">
    //             <div className=" mb-2 blog-search-form shadow">
    //               <form className="action d-flex">
    //                <input type="text" placeholder="Search Your Query Here " id="blog-search">
    //                <input type="submit" value="Search" id="blog-btn-search">
    //               </form>
    //             </div>
    //             <div className="vjed-blog-page my-3 shadow">
    //               <div className="blog-section">
    //                 <div className="add-img ">   <img src="images/vjads1.png" alt="vjads"  style="width: 75%;"/></div>



    //               </div>
    //             </div>
    //             <div className="vjed-blog-page blogsticy shadow">
    //               <div className="blog-section">

    //                 <div className="blog-top-cg">
    //                   <h6 className="mb-0">TOP CATEGORIES</h6>
    //                 </div>
    //                 <div className="add-img my-2">   <img src="images/vjads4.png" alt="vjads" style="width: 75%;"/></div>
    //                 <div className="blog-top-cg-links mb-3">
    //                   <a href="#">
    //                   <i className="fa fa-angle-right" aria-hidden="true"></i>
    //                     Mobile App Development
    //                   </a>
    //                   <a href="#">
    //                   <i className="fa fa-angle-right" aria-hidden="true"></i>
    //                     Android App Development
    //                   </a>
    //                   <a href="#">
    //                   <i className="fa fa-angle-right" aria-hidden="true"></i>
    //                     iPhone App Depelopment
    //                   </a>
    //                   <a href="#">
    //                   <i className="fa fa-angle-right" aria-hidden="true"></i>
    //                     Web Development
    //                   </a>
    //                   <a href="#">
    //                   <i className="fa fa-angle-right" aria-hidden="true"></i>
    //                     Educational App Development
    //                   </a>
    //                 </div>
    //                 <div className="py-2 blog-cg">
    //                   <div className="blog-cg-img">
    //                     <img src="images/blog-6.png" className="w-100" />
    //                     <h6><b>PREPARATION FOR</b></h6>
    //                     <h4><b>ICMR EXAM</b></h4>
    //                     <button type="button" className="btn-exp">Explore Now</button>
    //                   </div>
    //                 </div>
    //                 <div className="py-2 blog-cg">
    //                   <div className="blog-cg-img">
    //                     <img src="images/blog-6.png" className="w-100" />
    //                     <h6><b>PREPARATION FOR</b></h6>
    //                     <h4><b>ICMR EXAM</b></h4>
    //                     <button type="button" className="btn-exp">Explore Now</button>
    //                   </div>
    //                 </div>
    //                 <div className="py-2 blog-cg">
    //                   <div className="blog-cg-img">
    //                     <img src="images/blog-6.png" className="w-100" />
    //                     <h6><b>PREPARATION FOR</b></h6>
    //                     <h4><b>ICMR EXAM</b></h4>
    //                     <button type="button" className="btn-exp">Explore Now</button>
    //                   </div>
    //                 </div>
    //                 <div className=" py-2 blog-cg-latest mb-3 shadow rounded-3 p-2">
    //                   <div className="blog-top-cg">
    //                     <h6>LATEST BLOGS</h6>
    //                   </div>
    //                   <div className="d-flex align-items-center">
    //                     <div className="blog-latest-img p-1">
    //                       <img src="images/latest-b-1.png" className="img-fluid"/>
    //                     </div>
    //                     <div className="blog-latest-links p-1">
    //                       <a href="#">
    //                         How can 5G benefit the Mobile App Development Industry?
    //                       </a>

    //                         <h6>
    //                           <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                           14-jun-2023
    //                         </h6>

    //                     </div>
    //                   </div>
    //                   <div className="d-flex align-items-center">
    //                     <div className="blog-latest-img p-1">
    //                       <img src="images/latest-b-2.png" className="img-fluid"/>
    //                     </div>
    //                     <div className="blog-latest-links p-1">
    //                       <a href="#">
    //                         How can 5G benefit the Mobile App Development Industry?
    //                       </a>

    //                         <h6>
    //                           <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                           14-jun-2023
    //                         </h6>

    //                     </div>
    //                   </div>
    //                   <div className="d-flex align-items-center">
    //                     <div className="blog-latest-img p-1">
    //                       <img src="images/latest-b-3.png" className="img-fluid"/>
    //                     </div>
    //                     <div className="blog-latest-links p-1">
    //                       <a href="#">
    //                         How can 5G benefit the Mobile App Development Industry?
    //                       </a>

    //                         <h6>
    //                           <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                           14-jun-2023
    //                         </h6>

    //                     </div>
    //                   </div>
    //                   <div className="d-flex align-items-center">
    //                     <div className="blog-latest-img p-1">
    //                       <img src="images/latest-b-4.png" className="img-fluid"/>
    //                     </div>
    //                     <div className="blog-latest-links p-1">
    //                       <a href="#">
    //                         How can 5G benefit the Mobile App Development Industry?
    //                       </a>

    //                         <h6>
    //                           <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                           14-jun-2023
    //                         </h6>

    //                     </div>
    //                   </div>
    //                   <div className="d-flex align-items-center">
    //                     <div className="blog-latest-img p-1">
    //                       <img src="images/latest-b-5.png" className="img-fluid"/>
    //                     </div>
    //                     <div className="blog-latest-links p-1">
    //                       <a href="#">
    //                         How can 5G benefit the Mobile App Development Industry?
    //                       </a>

    //                         <h6>
    //                           <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                           14-jun-2023
    //                         </h6>

    //                     </div>
    //                   </div>
    //                   <div className="d-flex align-items-center">
    //                     <div className="blog-latest-img p-1">
    //                       <img src="images/latest-b-6.png" className="img-fluid"/>
    //                     </div>
    //                     <div className="blog-latest-links p-1">
    //                       <a href="#">
    //                         How can 5G benefit the Mobile App Development Industry?
    //                       </a>

    //                         <h6>
    //                           <i className="fa fa-calendar me-1" aria-hidden="true"></i>
    //                           14-jun-2023
    //                         </h6>

    //                     </div>
    //                   </div>
    //                 </div>

    //                 <div className="blog-popular-tag mb-3 shadow rounded-3 p-2">
    //                   <div className="blog-top-cg">
    //                     <h6>POPULAR TAGS</h6>
    //                   </div>
    //                   <div className="blog-popular-tag-links">
    //                     <a href="#">App Development</a>
    //                     <a href="#"> Education App </a>
    //                     <a href="#"> Web Depelopment</a>
    //                     <a href="#"> Mobile App</a>
    //                     <a href="#"> Technology</a>
    //                     <a href="#"> Java</a>
    //                     <a href="#">App Development</a>
    //                     <a href="#">Education App</a>
    //                     <a href="#">Web Depelopment</a>
    //                     <a href="#"> Mobile App</a>
    //                     <a href="#"> Technology</a>
    //                   </div>
    //                 </div>
    //                 <div className="blog-social-media mb-3 shadow rounded-3 p-2">
    //                   <div className="blog-top-cg">
    //                     <h6>OUR SOCIAL MEDIA HANDLES</h6>
    //                   </div>
    //                   <div className="blog-social-media-links mb-3">
    //                     <ul className="list-inline d-flex">
    //                       <li className="list-inline-item ">
    //                         <a className=" btn-youtube  " target="_blank" href="">
    //                          <i className="fa fa-youtube-play" aria-hidden="true"></i>
    //                         </a>
    //                       </li>
    //                       <li className="list-inline-item">
    //                         <a className=" btn-facebook   " target="_blank" href="">
    //                          <i className="fa fa-facebook" aria-hidden="true"></i>
    //                         </a>
    //                       </li>
    //                       <li className="list-inline-item">
    //                          <a className="  btn-instagram  " target="_blank" href="">
    //                           <i className="fa fa-instagram" aria-hidden="true"></i>
    //                          </a>
    //                        </li>


    //                        <li className="list-inline-item">
    //                          <a className="  btn-telegram" target="_blank" href="">
    //                           <i className="fa fa-telegram" aria-hidden="true"></i>
    //                          </a>
    //                        </li>
    //                        <li className="list-inline-item">
    //                         <a className="btn-app " target="_blank" href="">
    //                           <img src="images/Google Play Icon.jpg" alt="googleapp">
    //                         </a>
    //                       </li>
    //                  </ul>
    //                     <!-- <a href="#" className=" btn-youtube"><i className="fa fa-youtube-play" aria-hidden="true"></i></a>
    //                     <a href="#" className=" btn-facebook"><i className="fa fa-facebook" aria-hidden="true"></i></a>
    //                     <a href="#" className=" btn-instagram"><i className="fa fa-instagram" aria-hidden="true"></i></a>
    //                     <a href="#" className=" btn-telegram"><i className="fa fa-telegram" aria-hidden="true"></i></a>
    //                     <a href="#" className=" btn-app"><img src="images/Google Play Icon.jpg" alt="googleapp"></a> -->

    //                   </div>
    //                 </div>

    //                 <div className="blog-inquary-form shadow rounded-3">
    //                   <div className="blog-top-cg">
    //                     <h6 className="text-center">Join Appsquadz Learning Program</h6>
    //                   </div>
    //                    <div className="inquery">

    //                     <div className="form-outline inquey-field  my-3 d-flex">

    //                       <i className="fa fa-user" aria-hidden="true"></i>

    //                       <input type="text" placeholder="Name" name="name" id="name" className="form-control shadow-none border-0"/>

    //                     </div>
    //                     <div className="form-outline inquey-field  my-3 d-flex">

    //                       <i className="fa fa-phone" aria-hidden="true"></i>

    //                       <input type="number" placeholder="Mobile No."  name="mobile" id="mobile" className="form-control shadow-none border-0"/>

    //                     </div>
    //                     <div className="form-outline inquey-field  my-3 d-flex">

    //                       <i className="fa fa-building" aria-hidden="true"></i>

    //                       <input type="text" placeholder="City" name="city" id="city" className="form-control shadow-none border-0"/>

    //                     </div>
    //                     <div className="form-outline inquey-field  my-3 d-flex">
    //                       <i className="fa fa-file-text" aria-hidden="true"></i>
    //                       <input type="text" placeholder="Grade/Exam" name="exam" id="exam"  className="form-control shadow-none border-0"/>

    //                     </div>
    //                     <div className="form-outline inquey-field  my-3 d-flex">
    //                       <i className="fa fa-envelope" aria-hidden="true"></i>
    //                       <input type="email" placeholder="Email Address" name="address" id="address" className="form-control shadow-none border-0"/>

    //                     </div>
    //                     <div className="form-outline inquey-btn text-center">
    //                       <input type="button" value="Submit" className="border-0" />
    //                     </div>


    //                    </div>


    //                 </div>


    //               </div>
    //             </div>
    //           </div>

    //         </div>
    //     </div>
    // </section>    
    {/* <!-- select option --> */ }
  )
}
