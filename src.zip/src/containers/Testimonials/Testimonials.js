export const testionial = [
    {
        name: 'Kunal Goyal',
        image: 'https://restapi.physicsgalaxy.com/testimonial/Kunal-Goyal.png',
        content: 'Starting from the basic level to the very advanced level Ashish Sir made our concepts crystal clear. Also, his website and his book Physics Galaxy were extremely useful tools throughout our JEE preparation. Feel fortunate to have you as our mentor.',
    }
]